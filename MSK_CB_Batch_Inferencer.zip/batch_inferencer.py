"""
model.config (can be stored on s3):

{
 "model_path":"s3://.........../model.tar.gz",
 "metadata":".........."
}

Script Usage:

python batch_inferencer.py --file_s3_uri "input_data_s3_path" --model_config "model_config_s3_path"

"""

import argparse
import pandas as pd
import numpy as np
import os, subprocess, multiprocessing, json, datetime
import sys
import gc
import boto3
import tarfile
import pickle
import general_functions as gf

import warnings
warnings.filterwarnings("ignore")

sys.path.append(os.getcwd())

from urllib.parse import urlparse

def Prepare_Model(local_model_pkl_path):
    
    def load_model(local_model_pkl_path):
        with open(local_model_pkl_path, 'rb') as f:
            model = pickle.load(f)
        return model
    try:
        model = load_model(local_model_pkl_path)
    except IsADirectoryError:
        local_model_pkl_path = os.path.join(
            local_model_pkl_path, [pkl for pkl in os.listdir(local_model_pkl_path) if pkl.endswith(".pkl")][0]
        )
    finally:
        model = load_model(local_model_pkl_path)
    return model

def preprocess_for_model(single_raw_sample):
    processed_sample = preprocessing_logic(single_raw_sample)
    return processed_sample

def get_prediction(single_sample, model_from_your_estimator_framework):   
    #single_prediction = model_from_your_estimator_framework.predict(single_sample)
    prob = model_from_your_estimator_framework.predict_proba(single_sample)
    return prob
    
def Batch_Inferencing(full_df, temp_dir, date, model, savefile=False, threshold=0.5, drop_features=True):
    
    NB_BATCHES = 10
    len_batch = len(full_df)//NB_BATCHES
    
    def get_predictions_over_a_subset(df, threshold):
        df["prediction_probabilities"] = df.apply(lambda x:get_prediction(x.values.reshape(1, -1), model)[0][1], axis=1)
        #df = df.assign(prediction=df.predictions.apply(lambda x:x[0][0]), 
                       #prediction_prob=df.predictions.apply(lambda x:x[1][0]))
        df['prediction'] = df.prediction_probabilities.apply(lambda x:1 if x>threshold else 0)
        #df.drop("predictions",  axis=1, inplace=True)
        return df

    generate_df = (full_df.iloc[i*len_batch:(i+1)*len_batch] for i in range(NB_BATCHES+1))
    
    if not os.path.isdir(temp_dir):
        os.mkdir(temp_dir)
        #date = datetime.datetime.today().date()
        #run_date = f"{date.year}{date.month}{date.day}"
    temp_dir = f"{temp_dir}/{date}"
    os.mkdir(temp_dir)
        
    for j,sub_df in enumerate(generate_df):
        if sub_df.empty:
            continue
        df_out = get_predictions_over_a_subset(sub_df, threshold)
        if drop_features:
            df_out = df_out.loc[:,["prediction_probabilities", "prediction"]]
        df_out.to_excel(os.path.join(temp_dir, f"Batch_{j}.xlsx"), index=False)
        print(f"==================Completed Model Inferencing for Batch No. {j}======================")

    Final_Preds = (
        pd.concat([pd.read_excel(os.path.join(temp_dir, file)) for file in os.listdir(temp_dir) if file.endswith(".xlsx")]).reset_index(drop=True)
    )
    output_filename = f"{temp_dir}/Final_Preds_{date}.xlsx"                                                    
    if savefile:                                                       
        Final_Preds.to_excel(output_filename, index=False)
        return output_filename
    return output_filename, Final_Preds

def s3_file_operation(s3_uri, op_type="read", upload_filename=None):
    """
    Reads/Downloads files from s3. Uploads local files to s3.
    
    Params:
    
    s3_uri: Full s3 uri for any operation
    op_type: String "read"/"download"/"upload" based on the operation type
    upload_filename: file to be uploaded from local. Only applicable when op_type is set to "upload"
    
    Returns:
    
    Only returns the last part (delimited by "/") of the s3 object key when op_type = "read"/"download".
    The relative path can then be passed on to next lines.
    
    Returns the full s3 path when op_type="upload"
    """
    parsed_uri = urlparse(s3_uri, allow_fragments=False)
    bucket = parsed_uri.netloc
    key = parsed_uri.path[1:]
    s3_client = boto3.client('s3', region_name='us-east-1')
    if op_type == "read":
        fileobj = s3_client.get_object(Bucket=bucket, Key=key)     
        filedata = fileobj['Body'].read()
        contents = filedata.decode('utf-8')
        return contents
    elif op_type == "download":
        s3_client.download_file(bucket, key, key.split("/")[-1])
        return key.split("/")[-1]
    elif op_type == "upload":
        if upload_filename is None:
            raise ValueError("Specify File to be upload from local file system")
        s3_client.upload_file(upload_filename, bucket , key+'/'+upload_filename)
        return f"s3://{bucket}/{key}/{upload_filename}"

def unzip_tar_gz(fname, destination):
    if fname.endswith("tar.gz"):
        tar = tarfile.open(fname, "r:gz")
        tar.extractall(destination)
        tar.close()
    elif fname.endswith("tar"):
        tar = tarfile.open(fname, "r:")
        tar.extractall(destination)
        tar.close()
    return destination

def reverse_transform(preprocess_pipeline, outputdf, categorical_features):
    a = preprocess_pipeline.named_transformers_['categorical']
    b = a.named_steps['encoder']
    c = b.inverse_transform(outputdf[categorical_features])
    outputdf.drop(categorical_features, axis=1, inplace=True)
    outputdf.reset_index(drop=True, inplace=True)
    e = pd.concat([pd.DataFrame(c, columns=categorical_features), outputdf], axis=1)
    return e

def updatedf(rawdf, predf, recoverlist):
    return pd.concat([rawdf[recoverlist],predf], axis=1)

def parse_arg():
    """
    This function parses command line arguments to this script
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--file_s3_uri", type=str, required=True)
    parser.add_argument("--model_config", type=str, required=True)
    params = vars(parser.parse_args())

    return params

if __name__ == "__main__":
    
    print("Parsing command line arguments......\n")
    params = parse_arg()  
    data_path = params["file_s3_uri"]
    config_uri = params["model_config"]
    

    print("Downloading Model Configurations From s3......\n") 
    model_config = json.loads(s3_file_operation(config_uri))
    model_path = model_config["Model_Path"]
    model_local_copy = s3_file_operation(model_path, op_type="download")
    model_local_copy = unzip_tar_gz(model_local_copy, "Trained_Model")

    print(f"Preparing Model......\n")
    model = Prepare_Model(model_local_copy)
    
    trigger_s3 = model_config["trigger_filepath"]
    trigger = json.loads(s3_file_operation(trigger_s3))

    str_tuple_claims = tuple(trigger['claims'])
    str_tuple_demo = tuple(trigger['demographics'])
    
    for claims_date, demo_date in zip(str_tuple_claims, str_tuple_demo):
        
        print(f"Loading data for {claims_date}......\n")
        full_df = pd.read_csv(data_path.replace(".csv",f"_{claims_date}.csv"))
        df_copy = full_df.copy()
        if "recover_list" in model_config:
            full_df.drop(model_config["recover_list"], axis=1, inplace=True)

        print("Inferencing Started.....\n")
        pred_dir = "Predictions_dir"

        if "drop_features" in model_config:
            drop_features = model_config["drop_features"]
        else:
            drop_features = True

        if "threshold" in model_config:
            threshold = model_config["threshold"]
        else:
            threshold = 0.5

        local_output_preds_file, outputdf = Batch_Inferencing(full_df, pred_dir, claims_date, model, threshold=threshold,
                                                              drop_features=drop_features)

        if not drop_features:
            print("\nRunning Inverse Transform on transformed categorical features....")
            data_preprocessor_path = model_config["Preprocessor_Object_Path"]
            preprocessor_local_path = s3_file_operation(data_preprocessor_path, op_type="download")
            with open(preprocessor_local_path, 'rb') as f:
                preprocess_pipeline = pickle.load(f)

            categorical_features = model_config["categorical_features"]
            outputdf[categorical_features] =  outputdf[categorical_features].astype(float)
            outputdf = reverse_transform(preprocess_pipeline, outputdf, categorical_features)

        if "recover_list" in model_config:
            outputdf = updatedf(df_copy,outputdf, model_config["recover_list"])
        #outputdf = outputdf.assign(probability_labels=[np.array(["No","Yes"])]*len(outputdf),
                                   #probability_threshold=threshold)
        outputdf = outputdf.loc[:,~outputdf.columns.duplicated()]
        outputdf.to_excel(local_output_preds_file, index=False)

        print("Copy to s3 Started......\n")
        output_s3_key_uri = model_config["Output_File_Path"]
        #output_s3_uri = s3_file_operation(output_s3_key_uri, op_type="upload", upload_filename=local_output_preds_file)

        parquet_version = local_output_preds_file.replace("xlsx", "parquet")
        outputdf.to_parquet(parquet_version, index=False)
        output_s3_uri = s3_file_operation(output_s3_key_uri, op_type="upload", upload_filename=parquet_version)

        csv_version = local_output_preds_file.replace("xlsx", "csv")
        outputdf.to_csv(csv_version, index=False)
        output_s3_uri = s3_file_operation(output_s3_key_uri, op_type="upload", upload_filename=csv_version)

        print("Predictions Saved.......!!\n")

        print("Updating run details in config.......\n")
        date = datetime.datetime.today().date()
        run_date = f"{date.year}-{date.month}-{date.day}"
        model_config["last_run"] = run_date 
        with open("model.config", 'w') as f:
            json.dump(model_config, f, indent=4)    
        output_s3_uri = s3_file_operation(config_uri.replace("/model.config",""), op_type="upload", upload_filename="model.config")

        print("Config Updated......!!")
