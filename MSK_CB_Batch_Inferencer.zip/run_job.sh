#!/bin/bash

python batch_inferencer.py --file_s3_uri ${dataset_path} --model_config ${config_path}