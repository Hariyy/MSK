import numpy as np
import pandas as pd

import os, sys, pickle, json, warnings, json, argparse, boto3, tarfile, re

from sklearn.preprocessing import StandardScaler, OrdinalEncoder, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.base import BaseEstimator
from sklearn.model_selection import train_test_split

#from imblearn.over_sampling import SMOTE
from urllib.parse import urlparse
from pyathena import connect

sys.path.append(os.getcwd())
import general_functions as gf

import warnings
warnings.filterwarnings("ignore")

class PassthroughTransformer(BaseEstimator):
      def fit(self, X, y = None):
        self.cols = X.columns
        return self

      def transform(self, X, y = None):
        self.cols = X.columns
        return X.values

      def get_feature_names(self):
        return self.cols


def merge_dataframes(MSK_Data_Path, demo_args_list, drop_cols=False, cols_to_drop=None):
    """Merge high spend and demographics data to create a single raw dataset
       Params: s3 path to all datasets"""
    # read MSK_data
    MSKdata = pd.read_csv(MSK_Data_Path).rename(columns = {'partneremployerid':'client_id'})
    # read all demographics data
    demo_chunks = [pd.read_csv(s3_path) for s3_path in demo_args_list]
    # concatenate all demographics data into one df
    full_demo_data = pd.concat(demo_chunks, axis=0, join="inner", ignore_index=False, keys=None, levels=None,
                                       names=None,verify_integrity=False, copy=False)
    # merge high spend & demographics data
    MSK_final_data = pd.merge(MSKdata, full_demo_data, how = 'inner', on = ['person_internal_id', 'client_id'])
    # Drop columns if needed
    if drop_cols:
        if cols_to_drop is None:
            raise RuntimeError("Specify columns to drop in cols when drop_cols is set to True")
        MSK_final_data.drop(cols_to_drop, axis=1, inplace=True)
    return MSK_final_data

def pull_merged_data_using_athena(str_tuple_claims, str_tuple_demo):

    query =   f"""SELECT t1.*,t2.* FROM 
              "adl-core-hype-predictive-models-db"."hs-claims-msk_cb" t1
              INNER JOIN
              "adl_core_dev_hype_high_spend_db"."demographics" t2
               ON t1.person_internal_id = t2.person_internal_id
               AND t1.partneremployerid = t2.client_id
               WHERE t1.partition_0 in ('{str_tuple_claims}')
                     AND t2.partition_0 in ('{str_tuple_demo}')"""

    connect_obj = connect(s3_staging_dir="s3://adl-core-dev-sagemaker-studio/external/Hype/Athena_Output",
                          region_name="us-east-1")

    df_hs = pd.read_sql(query, connect_obj)
    
    print(df_hs.shape)
    
    return df_hs


def remove_bytes_curse_from_data(df_hs):
      
    def clean_bytes_string(text):
        if isinstance(text, bytes):
            text = text.decode()
        if text in [None, '','n/a']:
            return np.nan
        #print(type(text))
        #print(text)
        m = re.search("b\'(.+?)\'", text)
        #print(type(m)) 
        if m:
            found = m.group(1)
        else:
            return text
        return found
    
    df_hs.dropna(axis=1, how='all', inplace=True)
    col_list = df_hs.select_dtypes("object").columns.tolist()

    for i,col in enumerate(col_list):
        if col == 'partition_0':
            continue
        df_hs[col] = df_hs[col].apply(lambda x:clean_bytes_string(x))
        print(f"{col}...Done!")
        
    df_hs = df_hs.loc[:,~df_hs.columns.duplicated()]
    
    return df_hs


def create_target(HS_final_data, target_col):
    """Create target variable  in the merged high spend dataset. Required during Model Training
       Not Applicable for Model Inferencing"""
    HS_final_data = HS_final_data.assign(target = HS_final_data[target_col].map({"Yes":1,"No":0}))
    HS_final_data.drop(target_col, axis=1, inplace=True)
    return HS_final_data

def apply_data_cleaning(MSK_final_data):
    """Apply mapping functions to fixed columns from general_functions module"""
    MSK_final_data['gender'] = gf.clean_gender(MSK_final_data['gender'])
    MSK_final_data['marital_status'] = gf.clean_marital_status(MSK_final_data['marital_status'])
    MSK_final_data['platform_indicator_code'] = gf.clean_platform_indicator_code(MSK_final_data["platform_indicator_code"])
    MSK_final_data['mapped_employment_status_code'] = gf.clean_mapped_employment_status_code(
        MSK_final_data["mapped_employment_status_code"]
    )
    return MSK_final_data

def filter_data(MSK_final_data, cols_to_filter):
    return MSK_final_data.loc[:,cols_to_filter]

def create_data_preprocessor(numeric_features, categorical_features, passthrough_features, fit=False, data=None, target=None):
    
    # create pipeline object for numerical features - more steps can be added
    imputer_trasformer = ColumnTransformer(transformers =[
        ('cat', SimpleImputer(strategy ='most_frequent'), categorical_features),
        ('Lable_Encoder',  OrdinalEncoder(), passthrough_features),
        ('num', SimpleImputer(strategy ='median'), numeric_features)
        #('pass_1' , PassthroughTransformer(), passthrough_features)
    ], remainder ='passthrough')
    ##numeric_transformer = SimpleImputer(strategy='median')
    # create pipeline object separately for categorical features
    
    one_hot_encode_transformer =  ColumnTransformer(transformers  =[
    ('one_hot_enconder', OneHotEncoder(sparse = False), list(range(len(categorical_features)))),
    #('pass_3' , PassthroughTransformer(), passthrough_features)
    ],remainder ='passthrough')
    """
    if len(label_encode_features) > 0:
        lable_encode_transformer = ColumnTransformer(transformers =[
       ('pass_2' , PassthroughTransformer(), one_hot_features + numeric_features + passthrough_features),
       ('Lable_Encoder',  OrdinalEncoder(), label_encode_features)
        ])
    
        preprocessor = Pipeline(steps =[
        ('Imputation_Step', imputer_trasformer),
        ('Label_Encoding_Step', lable_encode_transformer),
        ('One_Hot_Encoding_Step', one_hot_encode_transformer)  
        ])
    else:
    """
    preprocessor = Pipeline(steps =[
        ('Imputation_Step', imputer_trasformer),
        ('One_Hot_Encoding_Step', one_hot_encode_transformer)  
        ])
    ##categorical_transformer = Pipeline(steps=[
    ##('imputer', SimpleImputer(strategy='most_frequent')),
    ##('encoder', OrdinalEncoder())])
    ##categorical_one_hot_transformer = 
    # preprocessor column transformer that runs above pipeline sequentially
    ##preprocessor = ColumnTransformer(transformers=[
      ##  ('numeric', numeric_transformer, numeric_features),
        ##('categorical', categorical_transformer, categorical_features),
        ##('pass' , PassthroughTransformer(), passthrough_features)
        ##])
    if fit:
        if data is None:
            raise RuntimeError("Provide data to fit preprocessor when fit is set to True")
        else:
            if target:
                data = data.copy()
                data.drop(target, axis=1, inplace=True)
            preprocessor.fit(data)
    return preprocessor

def get_feature_names(column_transformer):
    """Get feature names from all transformers.
    Returns
    -------
    feature_names : list of strings
        Names of the features produced by transform.
    """
    # Turn loopkup into function for better handling with pipeline later
    def get_names(trans):
        # >> Original get_feature_names() method
        if trans == 'drop' or (
                hasattr(column, '__len__') and not len(column)):
            return []
        if trans == 'passthrough':
            if hasattr(column_transformer, '_df_columns'):
                if ((not isinstance(column, slice))
                        and all(isinstance(col, str) for col in column)):
                    return column
                else:
                    return column_transformer._df_columns[column]
            else:
                indices = np.arange(column_transformer._n_features)
                return ['x%d' % i for i in indices[column]]
        if not hasattr(trans, 'get_feature_names'):
        # >>> Change: Return input column names if no method avaiable
            # Turn error into a warning
            warnings.warn("Transformer %s (type %s) does not "
                                 "provide get_feature_names. "
                                 "Will return input column names if available"
                                 % (str(name), type(trans).__name__))
            # For transformers without a get_features_names method, use the input
            # names to the column transformer
            if column is None:
                return []
            else:
                return [name + "__" + f for f in column]

        return [name + "__" + f for f in trans.get_feature_names()]
    
    ### Start of processing
    feature_names = []
    
    # Allow transformers to be pipelines. Pipeline steps are named differently, so preprocessing is needed
    if type(column_transformer) == Pipeline:
        l_transformers = [(name, trans, None, None) for step, name, trans in column_transformer._iter()]
    else:
        # For column transformers, follow the original method
        l_transformers = list(column_transformer._iter(fitted=True))
    
    
    for name, trans, column, _ in l_transformers: 
        if type(trans) == Pipeline:
            # Recursive call on pipeline
            _names = get_feature_names(trans)
            # if pipeline has no transformer that returns names
            if len(_names)==0:
                _names = [name + "__" + f for f in column]
            feature_names.extend(_names)
        else:
            feature_names.extend(get_names(trans))
    
    return feature_names


def split_dataset(X_transformed, y_actual):
    validation_row = int(X_transformed.shape[0]/100)
    X = X_transformed.iloc[:-validation_row]
    y = y_actual.iloc[:-validation_row]
    X_train, X_test, y_train, y_test = train_test_split(X ,y ,test_size=0.25, shuffle=True, random_state=123)
    print(f"Shape of Training Set: {X_train.shape}\n")
    print(f"Shape of Test Set: {X_test.shape}\n")
    print(f"Retrieve last {validation_row} rows from X_transformed for validation")
    return X_train, X_test, y_train, y_test

def upsample_training_set(X_train, y_train):
    # define undersample strategy
    SMOTE_ = SMOTE()
    # fit and apply the transform
    X_train_SMOTE, y_train_SMOTE = SMOTE_.fit_resample(X_train, y_train)
    return X_train_SMOTE, y_train_SMOTE

def s3_file_operation(s3_uri, op_type="read", upload_filename=None):
    """
    Reads/Downloads files from s3. Uploads local files to s3.
    
    Params:
    
    s3_uri: Full s3 uri for any operation
    op_type: String "read"/"download"/"upload" based on the operation type
    upload_filename: file to be uploaded from local. Only applicable when op_type is set to "upload"
    
    Returns:
    
    Only returns the last part (delimited by "/") of the s3 object key when op_type = "read"/"download".
    The relative path can then be passed on to next lines.
    
    Returns the full s3 path when op_type="upload"
    """
    parsed_uri = urlparse(s3_uri, allow_fragments=False)
    bucket = parsed_uri.netloc
    key = parsed_uri.path[1:]
    #print(key)
    s3_client = boto3.client('s3', region_name='us-east-1')
    if op_type == "read":
        fileobj = s3_client.get_object(Bucket=bucket, Key=key)     
        filedata = fileobj['Body'].read()
        contents = filedata.decode('utf-8')
        return contents
    elif op_type == "download":
        s3_client.download_file(bucket, key, key.split("/")[-1])
        return key.split("/")[-1]
    elif op_type == "upload":
        if upload_filename is None:
            raise ValueError("Specify File to be upload from local file system")
        s3_client.upload_file(upload_filename, bucket , key+'/'+upload_filename)
        return f"s3://{bucket}/{key}/{upload_filename}"

def create_tar_gz(source_dir, fname):
    with tarfile.open(fname, "w:gz") as tar:
        for fn in os.listdir(source_dir):
            p = os.path.join(source_dir, fn)
            tar.add(p, arcname=fn)
    print(f"{fname} created for all files in {source_dir}")

def updatedf(predf, rawdf, recoverlist): 
    return pd.concat([rawdf[recoverlist],predf], axis=1)

def parse_arg():
    """
    This function parses command line arguments to this script
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--preprocessor_config", type=str, required=True)
    parser.add_argument("--output_file_location", type=str, required=True)
    params = vars(parser.parse_args())
    
    return params

if __name__ == "__main__":
    
    
    print("Parsing command line arguments......\n")
    params = parse_arg()  
    config_uri = params["preprocessor_config"]
    output_file_s3_path = params["output_file_location"]
    
    print("Downloading PreProcess Config File From s3......\n") 
    preprocess_config = json.loads(s3_file_operation(config_uri))
    
    trigger_s3 = preprocess_config["trigger_filepath"]
    trigger = json.loads(s3_file_operation(trigger_s3))

    str_tuple_claims = tuple(trigger['claims'])
    str_tuple_demo = tuple(trigger['demographics'])
    
    for claims_date, demo_date in zip(str_tuple_claims, str_tuple_demo):
    
        print(f"Fetching Dataset from Athena table for {claims_date}....\n")
        #HS_final_data = merge_dataframes(**preprocess_config["Merge_Step"])
        #claims_date, demo_date = tuple(list(claims_date)), tuple(list(demo_date))
        HS_final_data = pull_merged_data_using_athena(claims_date, demo_date)

        print("Removing the bytes curse from data......\n")
        HS_final_data = remove_bytes_curse_from_data(HS_final_data)
        rawdf = HS_final_data.copy()

        print("Cleaning merged dataset using general mapping functions......\n")
        HS_final_data = apply_data_cleaning(HS_final_data)

        print("\nFiltering Columns......\n")
        HS_final_data = filter_data(HS_final_data, cols_to_filter=preprocess_config["Filter_Columns"])

        print("Downloading & Unpickling Full Pipelined Data PreProcesser Pickle Object From s3......\n")
        data_preprocessor_path = preprocess_config["Preprocessor_Object_Path"]
        preprocessor_local_path = s3_file_operation(data_preprocessor_path, op_type="download")
        with open(preprocessor_local_path, 'rb') as f:
            preprocess_pipeline = pickle.load(f)
        X_transformed = pd.DataFrame(preprocess_pipeline.transform(HS_final_data))
                                     #columns = get_feature_names(preprocess_pipeline))
        #X_transformed.columns = [col.replace("numeric__","").replace("categorical__","").replace("pass__","") for col in X_transformed.columns]

        print("Saving Transformed Dataset to s3......\n")
        if "recover_list" in preprocess_config:
            X_transformed = updatedf(X_transformed, rawdf, preprocess_config["recover_list"])
        X_transformed.to_csv(output_file_s3_path.replace(".csv",f"_{claims_date}.csv"), index=False)

        print("Transformed Dataset Saved...!!")
    