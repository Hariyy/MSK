#!/bin/bash

python3 data_preprocessor.py --preprocessor_config ${preprocessor_config} --output_file_location ${output_file_location}