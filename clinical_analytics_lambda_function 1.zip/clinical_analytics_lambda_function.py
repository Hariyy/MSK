from datetime import datetime
import json
import os
import boto3

def check_job_status(client, job_id):
    response = client.describe_jobs(jobs=[job_id])
    job_status = response['jobs'][0]['status']
    return job_status

def lambda_handler(event, context):
    # TODO implement
    if "detail-type" in event.keys():
        timestampStr = datetime.today().strftime("%d_%b_%Y")
        client = boto3.client('batch')
        response = client.submit_job(
            jobDefinition=os.getenv('ClinicalAnalytics_JobDefinition'),
            jobName=f"Clinical_Analytics_MSK_Weekly_Refresh_{timestampStr}",
            jobQueue=os.getenv('Job_Queue'),
            shareIdentifier="clinicalanalytics"
        )
        print("Job Submitted")
    
        # Store the jobId in an S3 JSON file
        s3_client = boto3.client('s3')
        s3_bucket = 'adl-core-dev-sagemaker-studio'
        s3_key = f'external/Kamal/test_msk/clinical_analytics_msk.json'
        s3_response_data = {'jobId': response['jobId']}
    
        s3_client.put_object(
            Bucket=s3_bucket,
            Key=s3_key,
            Body=json.dumps(s3_response_data)
        )
    
        print("Job ID:", response['jobId'])
        
        # Wait for the job to complete
        while True:
            job_status = check_job_status(client, response['jobId'])
            print("Job Status:", job_status)
            if job_status == 'SUCCEEDED':
                break
            elif job_status in ['FAILED', 'STOPPED']:
                print("Job failed or stopped.")
                # Handle error condition if needed
                break
            # Wait for some time before checking the status again
            import time
            time.sleep(30)
    
        # Read JSON data from S3 and retrieve the job ID
        s3_client = boto3.client('s3')
        bucket_name = 'adl-core-dev-sagemaker-studio'
        file_path = f'external/Kamal/test_msk/clinical_analytics_msk.json'
        
        response = s3_client.get_object(Bucket=bucket_name, Key=file_path)
        json_content = response['Body'].read()
        json_data = json.loads(json_content)
        job_id = json_data["jobId"]
        print("Job ID from JSON:", job_id)
        
        # Continue with sending SNS notification or other actions
        if job_status == 'SUCCEEDED':
            print("Job completed successfully.")
            client = boto3.client('sns')
            arn = os.getenv('Success_sns_topic')
            response = client.publish(TargetArn=arn,
                                      Message="Clinical Analytics MSK Weekly Refresh is completed. Access the output file from s3://adl-core-dev-alteryx-stage/ml_input/msk_clinical/Predictions_dir/ in AWS Dev environment",
                                      MessageStructure='string')
        else:
            print("Job failed or stopped.")
            client = boto3.client('sns')
            arn = os.getenv('Failure_sns_topic')
            response = client.publish(TargetArn=arn,
                                      Message="Clinical Analytics MSK Weekly Refresh Failed. ",
                                      MessageStructure='string')

    return {
        'statusCode': 200,
        'body': "Job Completed"
    }
