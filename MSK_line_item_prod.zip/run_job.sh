#!/bin/bash

python3 msk_line_item_prod.py