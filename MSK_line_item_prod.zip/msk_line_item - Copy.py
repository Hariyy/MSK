import datetime
import s3fs
import pandas as pd
import numpy as np
import pyarrow.parquet as pq
import pickle
import boto3
import xgboost
import time

#loading the config file and reading the paths
def download_model_from_s3(bucket_name, s3_key, local_filename):
    s3 = boto3.resource('s3')
    s3.Bucket(bucket_name).download_file(s3_key, local_filename)

bucket_name = 'adl-core-sagemaker-studio'
s3_key = 'external/Harish/msk_clinical/config.json'
local_file_path = 'config.json'
download_model_from_s3(bucket_name, s3_key, local_file_path)
config = pd.read_json('config.json')
s3_dict = config['clinical_dict']
icd10 = config['icd10']
proc_codes = config['proc_codes']
employee = config['employee']
patient = config['patient']
person_identifiers = config['person_identifiers']



#Loading the Line Item data and filter them on dates and employer  key 
def load_line_item_data(employer_key):
    today_int = int(datetime.datetime.now().strftime('%Y%m%d'))
    min_date = today_int - 30000  # 3 years ago
    fs = s3fs.S3FileSystem()
    s3_dict = config['clinical_dict']
    filters = [
        ('Start_Date_Key', '>=', min_date),
        ('Start_Date_Key', '<', today_int),
        ('Employer_Key', '==', employer_key)
        
    ]
    df = pd.DataFrame()
    for key in s3_dict.keys():
        dataset = pq.ParquetDataset(s3_dict[key], use_legacy_dataset=False, filesystem=fs, filters=filters)
        pq_df = dataset.read(
            columns=['Patient_Key', 'Employer_Key', 'Start_Date_Key','CPT_HCPCS_Procedure_Key', 'Diagnosis_ICD10_1_Key',
                     'Diagnosis_ICD10_2_Key', 'Diagnosis_ICD10_3_Key', 'Diagnosis_ICD10_4_Key',
                     'Diagnosis_ICD10_5_Key', 'Diagnosis_ICD10_6_Key']).to_pandas()
        df = pd.concat([df, pq_df], ignore_index=True)
        print(f'Finished loading {key}')
    return df


# Load ICD10 and Procedure files, then map keys to codes

def load_and_map_codes(df):
    fs = s3fs.S3FileSystem()

    # Load ICD10 codes
    icd10_dataset = pd.read_parquet(icd10) 
    df_codes = icd10_dataset[['DiagnosisKey', 'DiagnosisCode']]
    df_codes['DiagnosisKey'] = df_codes['DiagnosisKey'].astype('float64')
    mapping = dict(zip(df_codes['DiagnosisKey'], df_codes['DiagnosisCode']))

    # Map ICD10 keys to codes in the main dataframe
    for i in range(1, 7):
        col_name = f'Diagnosis_ICD10_{i}_Key'
        df[col_name] = df[col_name].map(mapping)

    # Load procedure codes
    proc_dataset = pd.read_parquet(proc_codes)
    df_proc = proc_dataset[['CPT_HCPCS_Procedure_Key', 'CPT_HCPCS_Procedure_Code']]
    proc_mapping = dict(zip(df_proc['CPT_HCPCS_Procedure_Key'], df_proc['CPT_HCPCS_Procedure_Code']))

    # Map procedure keys to codes in the main dataframe
    df['CPT_HCPCS_Procedure_Key'] = df['CPT_HCPCS_Procedure_Key'].map(proc_mapping)

    return df


#preprocessing the segregating the data into HIP KNEE and BACK 
def preprocess_data(df):
    # label columns
    df['YES_Knee'] = np.where(df['CPT_HCPCS_Procedure_Key'].isin(['27350','27438','27440','27441','27442','27443','27445','27446','27447','27448','27450','27455','27457','27486','27487']), 1, 0)
    df['YES_Hip'] = np.where(df['CPT_HCPCS_Procedure_Key'].isin(['27120','27125','27130','27161','27284','27286','27132','27134','27137','27138']), 1, 0)
    df['YES_Back'] = np.where(df['CPT_HCPCS_Procedure_Key'].isin(['22207','22214','22224','22533','22534','22558','22585','22612','22614','22630','22633','22634','22830','22857','22865','22867','22868','22869','22870','62380','63005','63012','63017','63030','63035','63042','63044','63047','63048','63056','63057','63081','63087','63090','63185','63190','63200','63655','63685','0221T','0222T','0275T','22632']), 1, 0)

    # shared features
    df['difficulty_walking'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['R262','R2689','R269']).any(axis=1), 1, 0)
    df['physical_therapy'] = np.where(df['CPT_HCPCS_Procedure_Key'].isin(['97161','97162','97163','97001','97164','97002','97750','97535','97530','97112','97110','97140','97760','97116','97012','97032','97014','G0283','97033','97034','97035','97018','97026','97010','97113','97150']), 1, 0)

    # knee features
    df['knee_injection'] = np.where(((df['CPT_HCPCS_Procedure_Key'].str.startswith('J')) | (df['CPT_HCPCS_Procedure_Key'].isin(['96365','96366','96367','96368','96369','96370','96371','96372','96373','96374','96375','96376','96377','96378','96379']))) & (df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M1711','M1712','M170','M2241','M179','M1710','M2242','M94261','M94262','M1731','M1732','M21161','M21162','M21061','M21062','M25561','M25562','M25569','M25461','M25462','M25661','M25662','Z96651','Z96652','Z96659','Z96653','S83241A','S83242A','S83241D','S83231A','S83242D','S83232A','M2391','S83281A','S83282A','M238X1','M2392','M222X1','M222X2','M7651','M7652','S83512A','S83512D','S83511A','S83511D','M7122','M7121','M2341','M2342','M25361','M25362','M2352','M2351','R262','R2689','R269']).any(axis=1)), 1, 0)
    df['drain_knee_joint'] = np.where((df['CPT_HCPCS_Procedure_Key'].isin(['20610','20611'])) & (df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M1711','M1712','M170','M2241','M179','M1710','M2242','M94261','M94262','M1731','M1732','M21161','M21162','M21061','M21062','M25561','M25562','M25569','M25461','M25462','M25661','M25662','Z96651','Z96652','Z96659','Z96653','S83241A','S83242A','S83241D','S83231A','S83242D','S83232A','M2391','S83281A','S83282A','M238X1','M2392','M222X1','M222X2','M7651','M7652','S83512A','S83512D','S83511A','S83511D','M7122','M7121','M2341','M2342','M25361','M25362','M2352','M2351','R262','R2689','R269']).any(axis=1)), 1, 0)
    df['knee_xray'] = np.where(df['CPT_HCPCS_Procedure_Key'].isin(['73564','73562','73560','73565']), 1, 0)
    df['knee_mri'] = np.where(df['CPT_HCPCS_Procedure_Key'].isin(['73721']), 1, 0)
    df['knee_effusion'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M25461','M25462']).any(axis=1), 1, 0)
    df['knee_stiffness'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M25661','M25662']).any(axis=1), 1, 0)
    df['knee_oa'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M1711','M1712','M170','M2241','M179','M1710','M2242','M94261','M94262','M1731','M1732']).any(axis=1), 1, 0)
    df['knee_deformity'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M21161','M21162','M21061','M21062']).any(axis=1), 1, 0)
    df['knee_pain'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M25561','M25562','M25569']).any(axis=1), 1, 0)
    df['meniscus_tear'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['S83241A','S83242A','S83241D','S83231A','S83242D','S83232A','M2391','S83281A','S83282A','M238X1','M2392']).any(axis=1), 1, 0)
    df['petellofemoral_disorder'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M222X1','M222X2','M7651','M7652']).any(axis=1), 1, 0)
    df['acl_injury'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['S83512A','S83512D','S83511A','S83511D']).any(axis=1), 1, 0)
    df['baker_cyst'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M7122','M7121']).any(axis=1), 1, 0)   
    df['knee_loose_body'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M2341','M2342']).any(axis=1), 1, 0)
    df['knee_instability'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M25361','M25362','M2352','M2351']).any(axis=1), 1, 0)
    # print("Finished Knee")

    # hip features 
    df['hip_injection'] = np.where(((df['CPT_HCPCS_Procedure_Key'].str.startswith('J')) | (df['CPT_HCPCS_Procedure_Key'].isin(['96365','96366','96367','96368','96369','96370','96371','96372','96373','96374','96375','96376','96377','96378','96379']))) & (df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M25551','M25552','M25559','M1611','M1612','M160','M169','M1610','M1652','M1651','M7061','M7062','M7071','M7072','M7060','M25651','M25652','Z96641','Z96642','Z96649','Z96643','R262','R2689','R269','M25851','M25852','Q6589','S73191A','S73192A','M7601','S76011A','M7602','M24151','S76011D','S73191D','S76012A','M24851','M25859','S76012D','M24152','S73192D','M24852','M25451','M7611','M7612','M25452']).any(axis=1)), 1, 0)
    df['drain_hip_joint'] = np.where((df['CPT_HCPCS_Procedure_Key'].isin(['20610','20611'])) & (df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M25551','M25552','M25559','M1611','M1612','M160','M169','M1610','M1652','M1651','M7061','M7062','M7071','M7072','M7060','M25651','M25652','Z96641','Z96642','Z96649','Z96643','R262','R2689','R269','M25851','M25852','Q6589','S73191A','S73192A','M7601','S76011A','M7602','M24151','S76011D','S73191D','S76012A','M24851','M25859','S76012D','M24152','S73192D','M24852','M25451','M7611','M7612','M25452']).any(axis=1)), 1, 0)
    df['hip_xray'] = np.where(df['CPT_HCPCS_Procedure_Key'].isin(['73502','72100','72170','73501','73522','72110','73521']), 1, 0)
    df['hip_pain'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M25551','M25552','M25559']).any(axis=1), 1, 0)
    df['hip_oa'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M1611','M1612','M160','M169','M1610','M1652','M1651']).any(axis=1), 1, 0)
    df['hip_bursitis'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M7061','M7062','M7071','M7072','M7060']).any(axis=1), 1, 0)
    df['hip_stiffness'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M25651','M25652']).any(axis=1), 1, 0)
    df['other_hip_disorders'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M25851','M25852','Q6589','S73191A','S73192A','M7601','S76011A','M7602','M24151','S76011D','S73191D','S76012A','M24851','M25859','S76012D','M24152','S73192D','M24852','M25451','M7611','M7612','M25452']).any(axis=1), 1, 0)
    # print("Finished Hip")

    # back features   
    df['back_xray'] = np.where(df['CPT_HCPCS_Procedure_Key'].isin(['72100','72110','72040','72050']), 1, 0)
    df['back_mri'] = np.where(df['CPT_HCPCS_Procedure_Key'].isin(['72148','72141','72158']), 1, 0)
    df['spine_injection'] = np.where(((df['CPT_HCPCS_Procedure_Key'].str.startswith('J')) | (df['CPT_HCPCS_Procedure_Key'].isin(['96365','96366','96367','96368','96369','96370','96371','96372','96373','96374','96375','96376','96377','96378','96379']))) & (df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M545','M549','M5416','M5116','M5417','M4726','M5117','M4727','M5441','M5442','M5431','M5432','M48061','M48062','M4807','M5136','M5126','M5137','M5127','M9903','M9904','M9905','M47816','M47817','M47896','M5440','M5430','M4316','M4317']).any(axis=1)), 1, 0)
    df['spine_pain'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M545', 'M549']).any(axis=1), 1, 0)
    df['radiculopathy'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M5416','M5116','M5417','M4726','M5117','M4727','M5441','M5442','M5431','M5432','M5440','M5430']).any(axis=1), 1, 0)
    df['stenosis'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M48061','M48062','M4807']).any(axis=1), 1, 0)
    df['disc_degeneration'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M5136','M5126','M5137','M5127']).any(axis=1), 1, 0)
    df['segmental_dysfunction'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M9903','M9901','M9904','M9905']).any(axis=1), 1, 0)
    df['spondylosis'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M47816','M47817','M47896']).any(axis=1), 1, 0)
    df['spondylolisthesis'] = np.where(df[['Diagnosis_ICD10_1_Key','Diagnosis_ICD10_2_Key','Diagnosis_ICD10_3_Key','Diagnosis_ICD10_4_Key','Diagnosis_ICD10_5_Key','Diagnosis_ICD10_6_Key']].isin(['M4316','M4317']).any(axis=1), 1, 0)
    # print("Finished Back")

    df_cleaned = df[['Patient_Key', 'Employer_Key', 'Start_Date_Key', 'YES_Knee', 'YES_Hip', 'YES_Back', 'difficulty_walking',
            'physical_therapy', 'drain_knee_joint', 'knee_xray', 'knee_mri',
            'knee_effusion', 'knee_oa', 'knee_deformity',
            'knee_pain', 'meniscus_tear', 'acl_injury',
            'baker_cyst', 'knee_loose_body', 'knee_instability', 'hip_injection',
            'drain_hip_joint', 'hip_xray', 'hip_pain', 'hip_oa', 'hip_bursitis',
            'hip_stiffness', 'other_hip_disorders', 'back_xray', 'back_mri',
            'spine_injection', 'spine_pain', 'radiculopathy', 'stenosis',
            'disc_degeneration', 'segmental_dysfunction', 'spondylosis',
            'spondylolisthesis', 'knee_stiffness', 'petellofemoral_disorder', 'knee_injection']]

    df_grouped = df_cleaned.groupby(['Patient_Key', 'Employer_Key']).agg({
        'YES_Back': 'max',
        'YES_Knee': 'max',
        'YES_Hip': 'max',
        'difficulty_walking': 'max',
        'physical_therapy': 'max',
        'drain_knee_joint': 'max',
        'knee_xray': 'max',
        'knee_mri': 'max',
        'knee_effusion': 'max',
        'knee_oa': 'max',
        'knee_deformity': 'max',
        'knee_pain': 'max',
        'meniscus_tear': 'max',
        'acl_injury': 'max',
        'baker_cyst': 'max',
        'knee_loose_body': 'max',
        'knee_instability': 'max',
        'hip_injection': 'max',
        'drain_hip_joint': 'max',
        'hip_xray': 'max',
        'hip_pain': 'max',
        'hip_oa': 'max',
        'hip_bursitis': 'max',
        'hip_stiffness': 'max',
        'other_hip_disorders': 'max',
        'back_xray': 'max',
        'back_mri': 'max',
        'spine_injection': 'max',
        'spine_pain': 'max',
        'radiculopathy': 'max',
        'stenosis': 'max',
        'disc_degeneration': 'max',
        'segmental_dysfunction': 'max',
        'spondylosis': 'max',
        'spondylolisthesis': 'max',
        'knee_stiffness': 'max',
        'petellofemoral_disorder': 'max',
        'knee_injection': 'max'
    }).reset_index()


    df_cigna = df_grouped
    fs = s3fs.S3FileSystem()

    employee_dataset = pd.read_parquet(employee)
    df_employee = employee_dataset[['Employee_Id','Person_Key']]

    employee_mapping = dict(zip(df_employee['Employee_Id'], df_employee['Person_Key']))

    patient_dataset = pd.read_parquet(config['patient'])
    df_patient = patient_dataset[['Person_Key','Employee_Id','DOB']]
    
    df_patient['Employee_Id'] = df_patient['Employee_Id'].map(employee_mapping)

    patient_dob_sex = df_patient[['Person_Key','Employee_Id','DOB']]

    # Drop patients that don't have a person_key or an associated employee_id, assuming they are bad data******
    patient_dob_sex['Person_Key'] = pd.to_numeric(patient_dob_sex['Person_Key'], errors='coerce')
    patient_dob_sex['Employee_Id'] = pd.to_numeric(patient_dob_sex['Employee_Id'], errors='coerce')
    
    patient_dob_sex.dropna(how='any', inplace=True)

    patient_merged = df_cigna.merge(patient_dob_sex, how='left', left_on = 'Patient_Key', right_on = 'Person_Key')
    
    # person_identifiers table merged with patient_merged
    person_identifiers = pd.read_parquet(person_identifiers)
    person_identifiers = person_identifiers[person_identifiers['Person_ID_Type'] in ['23', '24']]                   
    person_identifiers = person_identifiers[['Person_ID','Person_Key','Person_ID_Type']]
    person_identifiers['Person_Key'] = pd.to_numeric(person_identifiers['Person_Key'], errors='coerce')
    person_identifiers = person_identifiers.dropna(subset=['Person_Key'])            
    
    #Join the person_identifiers table with Person_Key to create the alight_person_id
    merged_df = pd.merge(patient_merged, person_identifiers, left_on = 'Employee_Id', right_on = 'Person_Key', how='inner')
    
    
    # Extract split_part(person.person_identifiers.person_id, '-', 2) as alight_person_id
    merged_df['alight_person_id'] = merged_df['Person_ID'].str.split('-').str[1]
    

    # Filter rows where alight_person_id is not empty
    merged_df = merged_df[merged_df['alight_person_id'].ne('')]
    merged_df['alight_person_id'] = merged_df['alight_person_id'].astype('int')
    

    
    today = datetime.date.today()
    year = today.year

    merged_df['age'] = year - pd.DatetimeIndex(merged_df['DOB']).year

    merged_df.drop(columns=['DOB'], inplace=True)

    # There are about 3% of patients who we don't have their age - they were not in the patient table.
    dropped_person_ids = list(merged_df[merged_df['age'].isna()].index)

    merged_df.dropna(how='any',inplace=True)

    ids = merged_df['alight_person_id'].copy()
    client_ids = merged_df['Employer_Key'].copy()

    return merged_df




#making the prediction on all the 3 usecases HIP KNEE And BACK

def predict_employee_ailments(merged_df):
    def load_model(filename, columns):
        model = pickle.load(open(filename, 'rb'))
        X = merged_df[columns].copy()
        return model.predict(X)
    
    knee_model = load_model('Knee_MSK.pkl', [
        'age',
        'physical_therapy',
        'knee_injection',
        'drain_knee_joint',
        'knee_xray',
        'knee_mri',
        'knee_effusion',
        'knee_stiffness',
        'knee_oa',
        'knee_deformity',
        'knee_pain',
        'meniscus_tear',
        'petellofemoral_disorder',
        'acl_injury',
        'baker_cyst',
        'knee_loose_body',
        'knee_instability',
        'difficulty_walking'
    ])
    
    hip_model = load_model('Hip_MSK.pkl', [
        'age',
        'physical_therapy',
        'hip_xray',
        'hip_injection',
        'drain_hip_joint',
        'hip_pain',
        'hip_oa',
        'hip_bursitis',
        'hip_stiffness',
        'other_hip_disorders',
        'difficulty_walking'
    ])
    
    back_model = load_model('Back_MSK.pkl', [
        'age',
        'back_xray',
        'back_mri',
        'spine_injection',
        'physical_therapy',
        'spine_pain',
        'radiculopathy',
        'stenosis',
        'disc_degeneration',
        'segmental_dysfunction',
        'spondylosis',
        'spondylolisthesis'
    ])
    
    ids = merged_df['alight_person_id']
    client_ids = merged_df['Employer_Key']
    results = pd.DataFrame({'person_internal_id': ids, 'client_id': client_ids})
    
    results['Knee'] = knee_model
    results['Hip'] = hip_model
    results['Back'] = back_model
    
    results['predictions'] = results[['Knee', 'Hip', 'Back']].any(axis=1).astype(int)
    results.dropna(how='any',inplace=True)
    rollup_results = results.groupby(['person_internal_id', 'client_id']).agg({
        'predictions': 'max'
    }).reset_index()
    
    rollup_results = rollup_results[['client_id', 'person_internal_id' , 'predictions']]
    
    rollup_results.drop_duplicates(inplace=True)
    print('rollup_results count  merging person_internal_id:', rollup_results.shape)
                                          
    return rollup_results



#saving the prediction to s#

def upload_predictions_to_s3(line_item_datak):
    # Fixed S3 bucket name
    bucket_name = 'adl-core-prod-alteryx-stage'
    
    # Generate a unique folder name based on the current date
    folder_name = datetime.datetime.now().strftime("%Y-%m-%d")
    
    # Generate the S3 keys for the CSV and Parquet files
    s3_key_csv = f"ml_input/msk_clinical1/Predictions_dir/{folder_name}/predictions.csv"
    s3_key_parquet = f"ml_input/msk_clinical1/Predictions_dir/{folder_name}/predictions.parquet"
    
    # Convert the DataFrame to CSV format and Parquet format
    csv_data = line_item_datak[['client_id', 'person_internal_id', 'predictions']].to_csv(index=False)
    parquet_data = line_item_datak[['client_id', 'person_internal_id', 'predictions']].to_parquet()
    
    # Upload the CSV data to S3
    s3 = boto3.client('s3')
    s3.put_object(Body=csv_data, Bucket=bucket_name, Key=s3_key_csv)
    s3.put_object(Body=parquet_data, Bucket=bucket_name, Key=s3_key_parquet)
    
    print("Predictions stored successfully in S3.")

    
    
#binding all the function to this function to perform all the steps in sequence

def predict_save(employer_key):
    df = load_line_item_data(employer_key)
    df = load_and_map_codes(df)
    df = preprocess_data(df)
    df = predict_employee_ailments(df)
    df = upload_predictions_to_s3(df)
    return df


if __name__ == "__main__":
    employer_key = 5117
    predict_save(employer_key)
    